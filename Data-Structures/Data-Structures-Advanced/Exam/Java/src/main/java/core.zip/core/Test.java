package core;

import javax.sound.midi.Track;
import java.util.Map;
import java.util.Set;

public class Test {
    Map<String, Track> tracksById;

    Map<String, String> trackTitleByTrackId;

    Map<String, String> trackAlbumsByTrackId;

    Map<String, Set<String>> tracksTitlesByAlbumName;


}
